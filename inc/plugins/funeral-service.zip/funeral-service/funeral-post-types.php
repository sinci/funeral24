<?php
/*
Plugin Name: Funeral Services Post Types & Taxonomies
Plugin URI:
Description: Funeral Services and Obituaries
Version: 1.0
Author: sinci
Author URI: https://www.sinci.at
License: GPL2
License: URI: https://www.gnu.org/licenses/gpl-2.0.html
*/

// Register style sheet
add_action( 'wp_enqueue_scripts', 'register_plugin_styles',100);
function register_plugin_styles() {
	wp_register_style('funeral-service', plugins_url( 'funeral-service/css/funeral-service.css' ) );
	wp_enqueue_style('funeral-service');
}

// Register script
add_action('wp_enqueue_scripts', 'register_plugin_scripts');
function register_plugin_scripts() {
    wp_register_script('funeral-service-script', plugins_url('funeral-service/js/custom.js'), array('jquery'), '1.0', true);
    wp_enqueue_script('funeral-service-script');
}

// Hook the function to the 'template_include' filter
add_filter('template_include', 'load_single_trauerfaelle_template');

function load_single_trauerfaelle_template($template) {
    // Check if the current post type is 'trauerfaelle'
    if (is_singular('trauerfaelle')) {
        // Look for the custom template file in the plugin directory
        $custom_template = plugin_dir_path(__FILE__) . 'single-trauerfaelle.php';

        // Check if the custom template file exists
        if (file_exists($custom_template)) {
            return $custom_template;
        }
    }

    // If not, return the original template
    return $template;
}

// Hook the function to the 'template_include' filter
add_filter('template_include', 'load_archive_trauerfaelle_template');

function load_archive_trauerfaelle_template($template) {
    // Check if the current page is the archive of the custom post type 'trauerfaelle'
    if (is_post_type_archive('trauerfaelle')) {
        // Look for the custom template file in the plugin directory
        $custom_template = plugin_dir_path(__FILE__) . 'archive-trauerfaelle.php';

        // Check if the custom template file exists
        if (file_exists($custom_template)) {
            return $custom_template;
        }
    }

    // If not, return the original template
    return $template;
}

// LOAD ACF-FIELD GROUP
function my_acf_json_load_point($paths) {
    // Remove the original path (optional).
    unset($paths[0]);

    // Append the new path within the plugin directory and return it.
    $paths[] = plugin_dir_path(__FILE__) . 'acfields';

    return $paths;
}

add_filter('acf/settings/load_json', 'my_acf_json_load_point');



// Register Costum Post Type
function cptui_register_my_cpts() {

	/**
	 * Post Type: trauerfaelle
	 */

	$labels = array(
		"name" => __( "Trauerfälle", "funeral" ),
		"singular_name" => __( "Trauerfälle", "funeral" ),
	);

	$args = array(
		"label" => __( "Trauerfälle", "funeral" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "trauerfaelle", "with_front" => true ),
		"query_var" => true,
		"menu_position" => 20,
		'menu_icon' => plugin_dir_url(__FILE__) . 'images/trauerfaelle.png',
		"supports" => array( "title", "post-formats", "comments" ),
	);

	register_post_type( "trauerfaelle", $args );


	/**
	 * Post Type: kerzen
	 */

	$labels = array(
		"name" => __( "Kerzen", "funeral" ),
		"singular_name" => __( "Kerzen", "funeral" ),
	);

	$args = array(
		"label" => __( "Kerzen", "funeral" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "kerzen", "with_front" => true ),
		"query_var" => true,
		'menu_icon' => plugin_dir_url(__FILE__) . 'images/kerzen.png',
		"supports" => array( "title" ),
	);

	register_post_type( "kerzen", $args );

	/**
	 * Post Type: blumen
	 */

	$labels = array(
		"name" => __( "Blumen", "funeral" ),
		"singular_name" => __( "Blumen", "funeral" ),
	);

	$args = array(
		"label" => __( "Blumen", "funeral" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "blumen", "with_front" => true ),
		"query_var" => true,
		'menu_icon' => plugin_dir_url(__FILE__) . 'images/blumen.png',
		"supports" => array( "title" ),
	);

	register_post_type( "blumen", $args );



	/**
	 * Post Type: kondolenz
	 */

	 $labels = array(
		"name" => __( "Kondolenzen", "funeral" ),
		"singular_name" => __( "Kondolenz", "funeral" ),
	);

	$args = array(
		"label" => __( "Kondolenzen", "funeral" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => false,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "kondolenzen", "with_front" => true ),
		"query_var" => true,
		'menu_icon' => "dashicons-welcome-write-blog",
		"supports" => array( "title" ),
	);

	register_post_type( "kondolenz", $args );

}

add_action( 'init', 'cptui_register_my_cpts' );


// Trauerfaelle pagination
function funeral_modify_archive_query( $query ) {
	if ( is_post_type_archive( 'trauerfaelle' ) && $query->is_main_query() ) {
		$query->set( 'posts_per_page', 6 );
	}
}
add_action( 'pre_get_posts', 'funeral_modify_archive_query' );


add_filter('acf/load_field/name=candles', 'candles_acf_load_field');
function candles_acf_load_field( $field ) {
    $field['choices'] = array(
		'candle_1' => '<div>'.'<img class="candle-images" width="150" src="' . plugins_url('images/candle.png', __FILE__ ) .'" alt="kerze" />' . '</div>',
		
		'candle_2' => '<div>'.'<img class="candle-images" width="150" src="' . plugins_url('images/candle2.png', __FILE__ ) .'" alt="kerze" />' . '</div>',
		
		'candle_3' => '<div>'.'<img class="candle-images" width="150" src="' . plugins_url('images/candle3.png', __FILE__ ) .'" alt="kerze" />' . '</div>',
    );
    return $field;
}

add_filter('acf/load_field/name=blumens', 'blumen_acf_load_field');
function blumen_acf_load_field( $field ) {
    $field['choices'] = array(
        'blumen_1' => '<img class="candle-images" width="150" src="' . plugins_url('/images/rote-rosen.png', __FILE__ ) .'" alt="rote-rosen" />',
        'blumen_2' => '<img class="candle-images" width="150" src="' . plugins_url('/images/weisse-rosen.png', __FILE__ ) .'" alt="weisse-rosen" />',
		'blumen_3' => '<img class="candle-images" width="150" src="' . plugins_url('/images/weisse-lilien.png', __FILE__ ) .'" alt="weisse-lilien" />'
    );
    return $field;
}

add_filter('acf/pre_save_post', 'my_pre_save_post');
function my_pre_save_post($post_id) {
    if (isset($_POST['current_form_type'])) {
        $cur_post_id = $_POST['current_post_id'];
        if ($_POST['current_form_type'] == "blumen") {
            $_POST['acf']['field_5b586fe35ce24'] = $cur_post_id;
        } elseif ($_POST['current_form_type'] == "kerzen") {
            $_POST['acf']['field_5b586fbbfc057'] = $cur_post_id;
        } elseif ($_POST['current_form_type'] == "kondolenz") {
            $_POST['acf']['field_6596ad12894a0'] = $cur_post_id;
        }
    }
    return $post_id;
}


add_filter('acf/update_value/name=name_kerzen', 'jb_update_postdata', 10, 3);
function jb_update_postdata( $value, $post_id, $field ) {
	$kerzennamen = $value;//get_field('name_kerzen', $post_id);//. ' ' . 
    $title = $kerzennamen;
	$slug = sanitize_title( $title );
	$postdata = array(
	     'ID'          => $post_id,
         'post_title'  => $title,
	     'post_type'   => 'kerzen',
	     'post_name'   => $slug
  	);
	wp_update_post( $postdata );
	return $value;
}

add_filter('acf/update_value/name=name_blumen', 'jb_update_postdata2', 10, 3);
function jb_update_postdata2( $value, $post_id, $field ) {
	$kerzennamen = $value;//get_field('name_blumen', $post_id). ' ' .
    $title = $kerzennamen;
	$slug = sanitize_title( $title );
	$postdata = array(
	     'ID'          => $post_id,
			'post_title' => $title,
	     'post_type'   => 'blumen',
	     'post_name'   => $slug
  	);
	wp_update_post( $postdata );
	return $value;
}

add_filter('acf/update_value/name=name_kondolenz', 'jb_update_postdata3', 10, 3);
function jb_update_postdata3( $value, $post_id, $field ) {
	$kerzennamen = $value;//get_field('name_blumen', $post_id). ' ' .
    $title = $kerzennamen;
	$slug = sanitize_title( $title );
	$postdata = array(
	     'ID'          => $post_id,
		'post_title' => $title,
	     'post_type'   => 'kondolenz',
	     'post_name'   => $slug
  	);
	wp_update_post( $postdata );
	return $value;
}

// Send E-Mail 
add_action('acf/save_post','send_admin_email_kerzen');
function send_admin_email_kerzen( $post_id ) {
	if( is_admin() ) {
		return;
	}
	$to = '';
	if( get_post_type($post_id) == 'blumen' ) {
		$post = get_post( $post_id );
		$name = get_field('name_blumen', $post_id);
		$text_blumen = get_field('text_blumen', $post_id);
		$parent_post_id = get_field('trauerfall_blumen', $post_id);
		$parent_post = get_post($parent_post_id);
		$subject = $post->post_title;
		//$headers[] = 'From: ' . $name . ' <site@>';
		$headers[] = 'Cc: ';
		$headers[] = 'Cc: ';
		$body = "Date: " . $post->post_date;
		$body .= '<br/>' . 'Post: Virtuelleblumen';
		$body .= '<br/>' . 'For: ' . $parent_post->post_title;
		$body .= '<br/>' . 'Text: ' . $text_blumen;
		$body .= '<br/>' . 'From: ' . $name;
		$body .= '<br/><a href="' .  admin_url( 'post.php?post=' . $post_id . '&action=edit') . '">Approve Here </a>';
		wp_mail($to, $subject, $body, $headers );
	} else if ( get_post_type($post_id) == 'kerzen' ) {
		$post = get_post( $post_id );
		$name = get_field('name_kerzen', $post_id);
		$text_kerzen = get_field('text_kerzen', $post_id);
		$parent_post_id = get_field('trauerfall_kerzen', $post_id);
		$parent_post = get_post($parent_post_id);
		$subject = $post->post_title;
		//$headers[] = 'From: ' . $name . ' <site@';
		$body = "Date: " . $post->post_date;
		$body .= '<br/>' . 'Post: Gedenkkerzen';
		$body .= '<br/>' . 'For: ' . $parent_post->post_title;
		$body .= '<br/>' . 'Text: ' . $text_kerzen;
		$body .= '<br/>' . 'From: ' . $name;
		$body .= '<br/><a href="' .  admin_url( 'post.php?post=' . $post_id . '&action=edit') . '">Approve Here </a>';
		wp_mail($to, $subject, $body, $headers );
	}
	
}

function mail_set_content_type(){
    return "text/html";
}
add_filter( 'wp_mail_content_type','mail_set_content_type' );
add_action( 'wp_ajax_save_my_data', 'acf_form_head' );
add_action( 'wp_ajax_nopriv_save_my_data', 'acf_form_head' );


// SHORTCODE TRAUERFAELLE
function custom_trauerfaelle_shortcode() {
	ob_start(); // Start output buffering

	$new_loop = new WP_Query( array(
			'post_type'      => 'trauerfaelle',
			'posts_per_page' => 6 // put the number of posts that you'd like to display
	) );

	if ( $new_loop->have_posts() ) :
			echo '<div class="uk-container ak-trauerfaelle">';
			echo '<div class="uk-grid-match" uk-grid>';

			while ( $new_loop->have_posts() ) : $new_loop->the_post();
					echo '<div class="uk-width-1-3@m">';
					echo '<div class="uk-card uk-card-default uk-card-body">';
					
					$plugin_dir_path = plugin_dir_path(__FILE__);
                    include $plugin_dir_path . 'template-parts/content-trauerfaelle.php';

					echo '</div>';
					echo '</div>';
			endwhile;

			echo '</div>';
			echo '</div>';

	else :
			echo '<p>No trauefaelle found.</p>';
	endif;

	wp_reset_postdata(); // Reset post data
	return ob_get_clean(); // Return the buffered content
}
add_shortcode('trauerfaelle', 'custom_trauerfaelle_shortcode');

// Add the custom columns to the 'blumen' post type:
add_filter('manage_blumen_posts_columns', 'set_custom_edit_blumen_columns');
function set_custom_edit_blumen_columns($columns) {
    unset($columns['trauerfallb']);
    $columns['trauerfallb'] = __('Trauerfall', 'your_text_domain');
    return $columns;
}

// Display data in the custom column in the 'blumen' post type admin screen:
add_action('manage_blumen_posts_custom_column', 'custom_blumen_column', 10, 2);
function custom_blumen_column($column, $post_id) {
    switch ($column) {
        case 'trauerfallb':
            // Assuming 'field_5b586fe35ce24' is the ACF field key storing the related post ID
            $related_post_id = get_field('field_5b586fe35ce24', $post_id);

            // Get the post title based on the related post ID
            $related_post_title = get_post_field('post_title', $related_post_id);

            // Display the related post title
            echo $related_post_title;
            break;
    }
}

// Add the custom columns to the 'kerzen' post type:
add_filter('manage_kerzen_posts_columns', 'set_custom_edit_kerzen_columns');
function set_custom_edit_kerzen_columns($columns) {
    unset($columns['trauerfallb']);
    $columns['trauerfallb'] = __('Trauerfall', 'your_text_domain');
    return $columns;
}

// Display data in the custom column in the 'blumen' post type admin screen:
add_action('manage_kerzen_posts_custom_column', 'custom_kerzen_column', 10, 2);
function custom_kerzen_column($column, $post_id) {
    switch ($column) {
        case 'trauerfallb':
            // Assuming 'field_5b586fe35ce24' is the ACF field key storing the related post ID
            $related_post_id = get_field('field_5b586fbbfc057', $post_id);

            // Get the post title based on the related post ID
            $related_post_title = get_post_field('post_title', $related_post_id);

            // Display the related post title
            echo $related_post_title;
            break;
    }
}

// Add the custom columns to the 'kondolenz' post type:
add_filter('manage_kondolenz_posts_columns', 'set_custom_edit_kondolenz_columns');
function set_custom_edit_kondolenz_columns($columns) {
    unset($columns['trauerfallb']);
    $columns['trauerfallb'] = __('Trauerfall', 'your_text_domain');
    return $columns;
}

// Display data in the custom column in the 'kondolenz' post type admin screen:
add_action('manage_kondolenz_posts_custom_column', 'custom_kondolenz_column', 10, 2);
function custom_kondolenz_column($column, $post_id) {
    switch ($column) {
        case 'trauerfallb':
            // Assuming 'field_5b586fe35ce24' is the ACF field key storing the related post ID
            $related_post_id = get_field('field_6596ad12894a0', $post_id);

            // Get the post title based on the related post ID
            $related_post_title = get_post_field('post_title', $related_post_id);

            // Display the related post title
            echo $related_post_title;
            break;
    }
}


