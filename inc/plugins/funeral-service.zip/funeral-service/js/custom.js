// KERZEN, BLUMEN, KONDOLENZ TAB
jQuery(document).ready(function($) {
    // Store the current URL without any parameters
    var baseUrl = window.location.origin + window.location.pathname;

    // Handle tab clicks
    $('ul.uk-tab li a').on('click', function(e) {
        e.preventDefault();

        // Get the tab name from the data-tab attribute
        var tabName = $(this).data('tab');

        // Update the URL with the tab parameter
        var newUrl = baseUrl + '?tab=' + tabName;
        window.history.pushState({ path: newUrl }, '', newUrl);

        // Reload the page
        window.location.reload();

        $('ul.uk-tab li').removeClass('uk-active');
        $(this).parent('li').addClass('uk-active');

        $('ul.uk-switcher li').removeClass('uk-active');
        $('ul.uk-switcher li[data-tab="' + tabName + '"]').addClass('uk-active');

    });
});

// COMMENT LENGTH KERZEN, BLUMEN, KONDOLENZ 
jQuery(document).ready(function($) {
    var textarea = $('#acf-field_5b586edee85d7');
    var textareab = $('#acf-field_5b586e91c6db6');
    var textareac = $('#acf-field_6596ad128942e');
    var charCountLabel = $('#charCountLabel span');

    textarea.on('input', function () {
      var remainingChars = 0 + textarea.val().length;
      charCountLabel.text('(' + remainingChars + '/160 Zeichen)');
    });

    textareab.on('input', function () {
        var remainingChars = 0 + textareab.val().length;
        charCountLabel.text('(' + remainingChars + '/160 Zeichen)');
      });

    textareac.on('input', function () {
      var remainingChars = 0 + textareac.val().length;
      charCountLabel.text('(' + remainingChars + '/160 Zeichen)');
    });

 });
