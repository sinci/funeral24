<?php
/**
 * The template for displaying archive pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package funeral
 */
acf_form_head();
get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main ">

        <?php if (have_posts()) : ?>

            <div class="uk-inline">
                <div class="post-thumbnail">
                    <img src="<?php echo get_template_directory_uri(); ?>/images/trauerfall.jpeg" width="2500" height="800" alt="trauerfaelle">
                </div>
                <div class="uk-overlay-primary uk-position-cover"></div>
                <div class="uk-overlay uk-position-center uk-light">
                    <header class="entry-header">
                        <?php
                        post_type_archive_title('<h1 class="page-title">', '</h1>');
                        ?>
                    </header><!-- .entry-header -->
                </div>
            </div>

            <div class="uk-container">
                <div class="uk-margin-top">
                    <?php echo do_shortcode('[wpdreams_ajaxsearchlite]'); ?>
                </div>
                <div uk-grid="masonry: true">
                    <?php
                    /* Start the Loop */
                    while (have_posts()) :
                        the_post();

                        ?>
                        <div class="uk-width-1-2@m">
                            <div class="uk-card uk-card-default uk-card-body">
                                <?php
                                /*
                                 * Include the template part for the content.
                                 * Modify the path to include it from the plugin directory.
                                 */
                                $plugin_dir_path = plugin_dir_path(__FILE__);
                                include $plugin_dir_path . 'template-parts/content-trauerfaelle.php';
                                ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>

            <!-- Add the pagination functions here. -->
            <?php
            echo '<div class="uk-flex uk-flex-center uk-padding">';
            wpex_pagination();
            echo '</div>';

        else :

            get_template_part('template-parts/content', 'none');

        endif;
        ?>

    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
?>
