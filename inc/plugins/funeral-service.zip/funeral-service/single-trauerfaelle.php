<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package funeral
 */
acf_form_head();
get_header();
?>

<div id="primary" class="content-area">
    <main id="main" class="site-main uk-margin-top">
        <?php
        while (have_posts()) :
            the_post();
            // Use plugin_dir_path to get the path to the plugin directory
            $plugin_dir_path = plugin_dir_path(__FILE__);

            // Include the template part from the plugin directory
            include $plugin_dir_path . 'template-parts/content-trauerfaelle.php';
        endwhile; // End of the loop.
        ?>
    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
?>

