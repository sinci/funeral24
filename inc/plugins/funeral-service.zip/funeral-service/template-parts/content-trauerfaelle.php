<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package funeral
 */

/*
 * Image templates
 */
$image = function ($attr) {
?>

<?php
};

$tab_name = "";
if(isset($_GET["tab"])){
	$tab_name = $_GET["tab"];
}

?>

<!-- Calculation Age -->
<?php
    $date = get_field('geburtsdatum');
    $date2 = get_field('sterbedatum');
    $birthday = new DateTime($date);
    $birthday2 = new DateTime($date2);
    $interval = $birthday->diff($birthday2);

    // Accessing the calculated age
    $age = $interval->y;
?>
<!-- Calculation Age End -->

<?php
$kerzen_args = array(
	'post_type' => 'kerzen',
	'meta_key' => 'trauerfall_kerzen',
	'meta_value' => get_the_ID(),
	'post_status' => 'publish',
	'posts_per_page' => -1,
);
$kerzen_posts = new WP_Query( $kerzen_args );
$count_kerzen = $kerzen_posts->post_count;

$blumen_args = array(
	'post_type' => 'blumen',
	'meta_key' => 'trauerfall_blumen',
	'meta_value' => get_the_ID(),
	'post_status' => 'publish',
	'posts_per_page' => -1,
);
$blumen_posts = new WP_Query( $blumen_args );
$count_blumen = $blumen_posts->post_count;

$kondolenz_args = array(
	'post_type' => 'kondolenz',
	'meta_key' => 'trauerfall_kondolenz',
	'meta_value' => get_the_ID(),
	'post_status' => 'publish',
	'posts_per_page' => -1,
);
$kondolenz_posts = new WP_Query( $kondolenz_args );
$count_kondolenz = $kondolenz_posts->post_count;

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('uk-container'); ?> >
	
<!-- Trauerfälle -->
<div class="uk-flex">
    <div class="uk-width-3-4">
        <?php if (is_single()) {
            
                echo '<div>';
                the_title('<h1 class="uk-article-title uk-margin-remove-top uk-float-left"><a class="uk-link-reset" href="' . esc_url(get_permalink()) . '">', '</a></h1>');
                echo '<span class="uk-float-left uk-margin-small-left">'. '(' . $age . ')' . '</span>';
                echo '</div>';
                echo '<div class="uk-clearfix"></div>';
                
            } else {
                
                echo '<div>';
                the_title('<h2 class="uk-article-title uk-margin-remove-top uk-float-left"><a class="uk-link-reset" href="' . esc_url(get_permalink()) . '">', '</a></h2>');
                echo '<span class="uk-float-left uk-margin-small-left">'. '(' . $age . ')' . '</span>';
                echo '</div>';
                echo '<div class="uk-clearfix"></div>';
                
            }
        ;?>

        <?php if( get_field('geburtsdatum') ): ?>
            <span class="geburtsdatum uk-margin-right">* <?php the_field('geburtsdatum'); ?></span>
        <?php endif; ?>
        
        <?php if( get_field('sterbedatum') ): ?>
            <span class="sterbedatum"> <img src="<?php echo plugins_url('../images/parte.svg', __FILE__); ?>" alt="parte" width="20" height="20"><?php the_field('sterbedatum'); ?></span>
        <?php endif; ?>

        <?php if (is_post_type_archive('trauerfaelle')) : ?>
		<h3 class="uk-h6 uk-margin-small-top uk-margin-remove-bottom"><a href="<?= get_permalink() ?>?tab=gedenkkerzen"><img src="<?php echo plugins_url('../images/kerze.svg', __FILE__); ?>" alt="gedenkkerzen" width="24" height="24"/>Gedenkkerzen (<?php echo $count_kerzen; ?>)</a></h3>
        <h3 class="uk-h6 uk-margin-small-top uk-margin-remove-bottom"><a href="<?= get_permalink() ?>?tab=virtuelleblumen"><img src="<?php echo plugins_url('../images/rose.svg', __FILE__); ?>" alt="virtuelle-blume" width="24" height="24"/>Virtuelleblumen (<?php echo $count_blumen ?>)</a></h3>
        <h3 class="uk-h6 uk-margin-small-top"><img src="<?php echo plugins_url('../images/kondolenzbuch.svg', __FILE__); ?>" alt="kondolenz" width="24" height="24"/> <a href="<?= get_permalink() ?>?tab=kondolenzen">Kondolenzbuch (<?php echo $count_kondolenz?>)</a></h3>
        <?php endif; ?>

        <?php if (is_post_type_archive('trauerfaelle')) : ?>
        <p><a class="uk-button uk-button-primary" href="<?= get_permalink() ?>">Zum Sterbefall</a></p>
        <?php endif ?>
        
        <?php if (is_single()) : ?>
            <div class="uk-margin-top">
            <?php if( get_field('verabschiedung') ): ?>
                <strong>Verabschiedung:</strong> <span><?php the_field('verabschiedung'); ?></span>
            <?php endif; ?>
            </div>

            <div>
            <?php if( get_field('uhrzeit') ): ?>
                <strong>Uhrzeit:</strong> <span><?php the_field('uhrzeit'); ?></span>
            <?php endif; ?>
            </div>

            <div>
            <?php if( get_field('ort') ): ?>
                <strong>Ort:</strong> <span><?php the_field('ort'); ?></span>
            <?php endif; ?>
            </div>

            <?php if( get_field('sonstiges') ): ?>
            <p><strong>Sonstiges:</strong> <?php the_field('sonstiges'); ?> </p>
            <?php endif; ?>
        <?php endif ?>

    </div>
    

    <div class="uk-width-1-4">
        <?php if( get_field('portrait') ): ?>
            <a href="<?= get_permalink() ?>"><img src="<?php the_field('portrait'); ?>" /></a>
        <?php endif; ?>         
    </div>

</div>
<!-- Trauerfälle END -->

	<div class="entry-content">
		<?php
		the_content( sprintf(
			wp_kses(
				/* translators: %s: Name of current post. Only visible to screen readers */
				__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'funeral' ),
				array(
					'span' => array(
						'class' => array(),
					),
				)
			),
			get_the_title()
		) );

		wp_link_pages( array(
			'before' => '<div class="page-links">' . esc_html__( 'Pages:', 'funeral' ),
			'after'  => '</div>',
		) );
		?>

<?php if (is_single()) : ?>

    <?php
// Check if 'updated' parameter is set and equals "true"
if (isset($_GET['updated']) && $_GET['updated'] == "true") :
?>
    
<script>
    document.addEventListener('DOMContentLoaded', function () {
        UIkit.modal.alert('Erfolgreich eingereicht');
        setTimeout(function () {
            window.location.replace(document.referrer);
        }, 5000); // Adjust the delay as needed
    });
</script>
<?php
    // Do not use $_GET['updated'] = "false" here, as it won't persist after the redirect
endif;
?>

<div id="tabs">
<ul class="uk-tab" uk-tab >
    <li <?php echo $tab_name == "parte" ? 'class="uk-active"' : ""; ?>><a href="#" data-tab="parte"> <img src="<?php echo plugins_url('../images/parte.svg', __FILE__); ?>" alt="parte" width="24" height="24"/><span class="links">Parte</span></a></li>
    <li <?php echo $tab_name == "gedenkkerzen" ? 'class="uk-active"' : ""; ?>><a href="#" data-tab="gedenkkerzen"> <img src="<?php echo plugins_url('../images/kerze.svg', __FILE__); ?>" alt="gedenkkerzen" width="24" height="24"/><span class="links">Gedenkkerzen</span> (<?php echo $count_kerzen ?>)</a></li>
    <li <?php echo $tab_name == "virtuelleblumen" ? 'class="uk-active"' : ""; ?>><a href="#" data-tab="virtuelleblumen"> <img src="<?php echo plugins_url('../images/rose.svg', __FILE__); ?>" alt="virtuelleblumen" width="24" height="24"/><span class="links">Virtuelleblumen</span> (<?php echo $count_blumen ?>)</a></li>
    <li <?php echo $tab_name == "kondolenzen" ? 'class="uk-active"' : ""; ?>><a href="#" data-tab="kondolenzen"> <img src="<?php echo plugins_url('../images/kondolenzbuch.svg', __FILE__); ?>" alt="kondolenzen" width="24" height="24"/> <span class="links">Kondolenzbuch</span> (<?php echo $count_kondolenz ?>)</a></li>
</ul>

<ul class="uk-switcher uk-margin">
	<li <?php echo $tab_name == "parte" ? 'class="uk-active"' : ""; ?>>
	<?php if( get_field('parte') ): ?>
		<img src="<?php the_field('parte'); ?>" />
	<?php endif; ?> 
	</li>
	<li <?php echo $tab_name == "gedenkkerzen" ? 'class="uk-active"' : ""; ?>>
	<div class="form-kerzen">
        <?php
        global $current_user;
        $current_user = wp_get_current_user();
        $post_title = $current_user->user_login . ' <' . $current_user->user_email . '>';
        acf_form(array(
            'form_attributes' => array(
                'class' => 'new-campaign-form'
            ),
            'post_id' => 'new_post',
            'html_before_fields' => '<input type="hidden" id="current_form_type" name="current_form_type" value="kerzen" /><input type="hidden" id="current_post_id" name="current_post_id" value="' . get_the_ID() .  '" />',
            'new_post' => array(
                'post_title' => $post_title,
                'post_type'	=> 'kerzen',
                'post_status' => 'publish'
            ),
            'updated_message' => __("Erfolgreich eingereicht", 'acf'),
            //'recaptcha' => true,
            'submit_value' => 'Gedenkkerze Entzünden!',
            'html_submit_button' => '<input id="kerzenbutton" type="submit" class="acf-button button button-primary button-large uk-button uk-button-primary" value="%s" />',

        ));
        ?>
    </div>
	<div class="kerzen-post-list select" uk-height-match>
		<?php
		if ( $kerzen_posts -> have_posts() ) {
			while ( $kerzen_posts->have_posts() ) {
				$kerzen_posts->the_post();
				echo '<div class="grid-view uk-text-small uk-text-center">';
					if( get_field('candles') == "candle_1" ):
						echo '<div class="candlbox">';
						echo '<img class="candle-images" width="150" src="' . plugins_url('../images/candle.gif', __FILE__) . '" alt="kerze" />';
						echo '</div>';
											
					elseif( get_field('candles') == "candle_2" ):
						echo '<div class="candlbox">';
						echo '<img class="candle-images" width="150" src="' . plugins_url('../images/candle.gif', __FILE__) . '" alt="kerze" />';
						echo '</div>';
					elseif( get_field('candles') == "candle_3" ):
						echo '<div class="candlbox">';
						echo '<img class="candle-images" width="150" src="' . plugins_url('../images/candle.gif', __FILE__) . '" alt="kerze" />';
						echo '</div>';
					endif;
					echo '<div class="kerzen-text uk-text-bold">';
					if( get_field('name_kerzen') ):
							the_field( 'name_kerzen' );
					endif;
					echo '</div>';
					echo '<div class="kerzen-text">';
					if( get_field('text_kerzen') ):
							the_field( 'text_kerzen' );
					endif;
					echo '</div>';
					echo '<div class="kerzen-date">'. get_the_date() .'</div>';
				echo '</div>';
			}
		}
		wp_reset_query();
		?>
	</div>
	</li>
	<li <?php echo $tab_name == "virtuelleblumen" ? 'class="uk-active"' : ""; ?>>
		<div class="form-kerzen"><?php
		global $current_user;
		$current_user = wp_get_current_user();
		$post_title = $current_user->user_login . ' <' . $current_user -> user_email . '>';
		acf_form(array(
				'post_id' => 'new_post',
				'html_before_fields' => '<input type="hidden" id="current_form_type" name="current_form_type" value="blumen" /><input type="hidden" id="current_post_id" name="current_post_id" value="' . get_the_ID() .  '" />',
				'new_post' => array(
					'post_title' => $post_title,
					'post_type'	=> 'blumen',
					'post_status' => 'publish'
					),
				//"recaptcha" => true,
				'updated_message' => __("Erfolgreich eingereicht", 'acf'),
				'submit_value' => 'Virtuelle Blume Niederlegen',
				'html_submit_button' => '<input id="vblumen" type="submit" class="acf-button button button-primary button-large uk-button uk-button-primary" value="%s" />',
			)); ?>
		</div>
		<div id="kerzenlist" class="kerzen-post-list"uk-height-match>
			<?php
			if ( $blumen_posts -> have_posts() ) {
				while ( $blumen_posts->have_posts() ) {
					$blumen_posts->the_post();
					echo '<div class="grid-view uk-text-small uk-text-center">';
						if( get_field('blumens') == "blumen_1" ):
							echo '<img class="candle-images" width="150" src="' . plugins_url('../images/rote-rosen.png', __FILE__) . '" alt="rote-rosen" />';
						elseif( get_field('blumens') == "blumen_2" ):
							echo '<img class="candle-images" width="150" src="' . plugins_url('../images/weisse-rosen.png', __FILE__) . '" alt="weisse-rosen" />';
						elseif( get_field('blumens') == "blumen_3" ):
							echo '<img class="candle-images" width="150" src="' . plugins_url('../images/weisse-lilien.png', __FILE__) . '" alt="weisse-lilien" />';
						endif;
						echo '<div class="kerzen-text uk-text-bold">';
						if( get_field('name_blumen') ):
								the_field( 'name_blumen' );
						endif;
						echo '</div>';
						echo '<div class="kerzen-text">';
						if( get_field('text_blumen') ):
								the_field( 'text_blumen' );
						endif;
						echo '</div>';
						echo '<div class="kerzen-date">'. get_the_date() .'</div>';
					echo '</div>';
				}
			}
			wp_reset_query();
			?>
		</div>
	</li>
	<li id="kondolenzbuch" <?php echo $tab_name == "kondolenzbuch" ? 'class="uk-active"' : ""; ?>>
	
	<div class="form-kerzen"><?php
		global $current_user;
		$current_user = wp_get_current_user();
		$post_title = $current_user->user_login . ' <' . $current_user -> user_email . '>';
		acf_form(array(
				'post_id' => 'new_post',
				'html_before_fields' => '<input type="hidden" id="current_form_type" name="current_form_type" value="kondolenz" /><input type="hidden" id="current_post_id" name="current_post_id" value="' . get_the_ID() .  '" />',
				'new_post' => array(
					'post_title' => $post_title,
					'post_type'	=> 'kondolenz',
					'post_status' => 'publish'
					),
				//"recaptcha" => true,
				'updated_message' => __("Erfolgreich eingereicht", 'acf'),
				'submit_value' => 'Kondolenz eintragen',
				'html_submit_button' => '<input id="vblumen" type="submit" class="acf-button button button-primary button-large uk-button uk-button-primary" value="%s" />',
			)); ?>
		</div>

		<div id="kerzenlist" class="kerzen-post-list">
			<?php
			if ( $kondolenz_posts -> have_posts() ) {
				while ( $kondolenz_posts->have_posts() ) {
					$kondolenz_posts->the_post();
					echo '<div class="kondolenzlist">';
	
						echo '<div class="kerzen-text uk-text-bold">';
						if( get_field('name_kondolenz') ):
								the_field( 'name_kondolenz' );
						endif;
						echo '</div>';
						echo '<div class="kerzen-text">';
						if( get_field('text_kondolenz') ):
								the_field( 'text_kondolenz' );
						endif;
						echo '</div>';
						echo '<div class="kerzen-date uk-text-small uk-text-right">'. get_the_date() .'</div>';
					echo '<hr></div>';
				}
			}
			wp_reset_query();
			?>
		</div>
	</li>

</ul>
</div>
<?php endif ?>
</div><!-- .entry-content -->

<footer class="entry-footer">
</footer><!-- .entry-footer -->

</article><!-- #post-<?php the_ID(); ?> -->	

